// TON Earn App - Main JavaScript File
// Handles all interactive functionality, animations, and core logic

class TONEarnApp {
    constructor() {
        this.currentLang = 'en';
        this.userBalance = 0.000;
        this.videosWatched = 0;
        this.dailyEarnings = 0.000;
        this.totalEarnings = 0.000;
        this.streakCount = 0;
        this.referralCount = 0;
        this.referralEarnings = 0.000;
        this.isVideoPlaying = false;
        this.currentVideoTime = 0;
        this.videoDuration = 30; // 30 seconds per video
        
        this.init();
    }
    
    init() {
        this.initParticles();
        this.initEventListeners();
        this.initAnimations();
        this.loadUserData();
        this.startPeriodicUpdates();
        this.initVideoPlayer();
        this.initLanguageToggle();
    }
    
    // Initialize particle background using p5.js
    initParticles() {
        new p5((p) => {
            let particles = [];
            const numParticles = 50;
            
            p.setup = () => {
                const canvas = p.createCanvas(p.windowWidth, p.windowHeight);
                canvas.parent('particles-canvas');
                
                // Create particles
                for (let i = 0; i < numParticles; i++) {
                    particles.push({
                        x: p.random(p.width),
                        y: p.random(p.height),
                        vx: p.random(-0.5, 0.5),
                        vy: p.random(-0.5, 0.5),
                        size: p.random(2, 6),
                        opacity: p.random(0.1, 0.3)
                    });
                }
            };
            
            p.draw = () => {
                p.clear();
                
                // Update and draw particles
                particles.forEach(particle => {
                    // Update position
                    particle.x += particle.vx;
                    particle.y += particle.vy;
                    
                    // Wrap around edges
                    if (particle.x < 0) particle.x = p.width;
                    if (particle.x > p.width) particle.x = 0;
                    if (particle.y < 0) particle.y = p.height;
                    if (particle.y > p.height) particle.y = 0;
                    
                    // Draw particle
                    p.fill(0, 212, 255, particle.opacity * 255);
                    p.noStroke();
                    p.circle(particle.x, particle.y, particle.size);
                });
                
                // Draw connections
                particles.forEach((particle, i) => {
                    particles.slice(i + 1).forEach(other => {
                        const distance = p.dist(particle.x, particle.y, other.x, other.y);
                        if (distance < 100) {
                            p.stroke(0, 212, 255, (1 - distance / 100) * 50);
                            p.strokeWeight(1);
                            p.line(particle.x, particle.y, other.x, other.y);
                        }
                    });
                });
            };
            
            p.windowResized = () => {
                p.resizeCanvas(p.windowWidth, p.windowHeight);
            };
        });
    }
    
    // Initialize all event listeners
    initEventListeners() {
        // Language toggle
        document.querySelectorAll('.lang-option').forEach(option => {
            option.addEventListener('click', (e) => {
                this.switchLanguage(e.target.dataset.lang);
            });
        });
        
        // Video player controls
        document.getElementById('play-btn').addEventListener('click', () => {
            this.startVideo();
        });
        
        document.getElementById('start-earning-btn').addEventListener('click', () => {
            this.startVideo();
        });
        
        // Navigation
        document.getElementById('login-btn').addEventListener('click', () => {
            window.location.href = 'login.html';
        });
        
        // Referral link copy
        document.querySelector('button[data-en="Copy"]').addEventListener('click', (e) => {
            this.copyReferralLink(e.target);
        });
        
        // Smooth scrolling for navigation
        document.querySelectorAll('a[href^="#"]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const target = document.querySelector(link.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });
    }
    
    // Initialize animations
    initAnimations() {
        // Animate elements on scroll
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);
        
        // Observe elements for animation
        document.querySelectorAll('.card-hover, .bg-gray-900').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            el.style.transition = 'all 0.6s ease';
            observer.observe(el);
        });
        
        // Animate balance counter
        this.animateCounter('total-balance', this.userBalance);
    }
    
    // Initialize video player
    initVideoPlayer() {
        const video = document.getElementById('main-video');
        const overlay = document.getElementById('video-overlay');
        const progressBar = document.getElementById('progress-bar');
        const progressText = document.getElementById('video-progress');
        
        // Simulate video content (in real app, this would load actual ads)
        video.addEventListener('loadedmetadata', () => {
            this.videoDuration = video.duration || 30;
        });
        
        video.addEventListener('timeupdate', () => {
            this.currentVideoTime = video.currentTime;
            const progress = (video.currentTime / this.videoDuration) * 100;
            
            progressBar.style.width = `${progress}%`;
            progressText.textContent = `${this.formatTime(video.currentTime)} / ${this.formatTime(this.videoDuration)}`;
            
            // Hide overlay once video starts playing
            if (video.currentTime > 0) {
                overlay.style.opacity = '0';
            }
        });
        
        video.addEventListener('ended', () => {
            this.completeVideo();
        });
    }
    
    // Initialize language toggle functionality
    initLanguageToggle() {
        const savedLang = localStorage.getItem('ton-earn-language') || 'en';
        this.switchLanguage(savedLang);
    }
    
    // Switch language
    switchLanguage(lang) {
        this.currentLang = lang;
        
        // Update active language option
        document.querySelectorAll('.lang-option').forEach(option => {
            option.classList.toggle('active', option.dataset.lang === lang);
        });
        
        // Update all text elements
        document.querySelectorAll(`[data-${lang}]`).forEach(element => {
            element.textContent = element.getAttribute(`data-${lang}`);
        });
        
        // Save preference
        localStorage.setItem('ton-earn-language', lang);
        
        // Update text direction for Bangla
        if (lang === 'bn') {
            document.body.dir = 'rtl';
        } else {
            document.body.dir = 'ltr';
        }
    }
    
    // Start video playback
    startVideo() {
        const video = document.getElementById('main-video');
        const overlay = document.getElementById('video-overlay');
        
        if (!this.isVideoPlaying) {
            this.isVideoPlaying = true;
            
            // Simulate video loading and playback
            this.simulateVideoPlayback();
            
            // Hide overlay
            anime({
                targets: overlay,
                opacity: 0,
                duration: 500,
                easing: 'easeOutQuad'
            });
        }
    }
    
    // Simulate video playback (in real app, this would play actual ads)
    simulateVideoPlayback() {
        const progressBar = document.getElementById('progress-bar');
        const progressText = document.getElementById('video-progress');
        
        let currentTime = 0;
        const duration = this.videoDuration;
        
        const playbackInterval = setInterval(() => {
            currentTime += 0.1;
            const progress = (currentTime / duration) * 100;
            
            progressBar.style.width = `${progress}%`;
            progressText.textContent = `${this.formatTime(currentTime)} / ${this.formatTime(duration)}`;
            
            if (currentTime >= duration) {
                clearInterval(playbackInterval);
                this.completeVideo();
            }
        }, 100);
    }
    
    // Complete video and award earnings
    completeVideo() {
        this.isVideoPlaying = false;
        this.videosWatched++;
        this.dailyEarnings += 0.001;
        this.totalEarnings += 0.001;
        this.userBalance += 0.001;
        
        // Update UI
        this.updateDashboard();
        this.showNotification('Great job! You earned 0.001 TON');
        
        // Check for achievements
        this.checkAchievements();
        
        // Auto-advance to next video after 2 seconds
        setTimeout(() => {
            this.prepareNextVideo();
        }, 2000);
        
        // Save progress
        this.saveUserData();
    }
    
    // Prepare next video
    prepareNextVideo() {
        const overlay = document.getElementById('video-overlay');
        const progressBar = document.getElementById('progress-bar');
        const progressText = document.getElementById('video-progress');
        
        // Reset progress
        progressBar.style.width = '0%';
        progressText.textContent = '0:00 / 0:30';
        
        // Show overlay with new video ready
        overlay.style.opacity = '1';
        
        // Update overlay content
        const overlayContent = overlay.querySelector('.text-center');
        overlayContent.innerHTML = `
            <button id="play-btn" class="w-20 h-20 bg-blue-500 hover:bg-blue-600 rounded-full flex items-center justify-center mb-4 transition-colors">
                <svg class="w-8 h-8 ml-1" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z"/>
                </svg>
            </button>
            <p class="text-lg mb-2">Next video ready!</p>
            <p class="text-sm text-gray-400">Earn 0.001 TON per video</p>
        `;
        
        // Re-attach play button listener
        document.getElementById('play-btn').addEventListener('click', () => {
            this.startVideo();
        });
    }
    
    // Update dashboard with current data
    updateDashboard() {
        // Animate counter updates
        this.animateCounter('total-balance', this.userBalance);
        this.animateCounter('daily-earnings', this.dailyEarnings);
        this.animateCounter('total-earnings', this.totalEarnings);
        
        // Update other stats
        document.getElementById('videos-watched').textContent = this.videosWatched;
        document.getElementById('goal-progress').textContent = `${this.videosWatched}/50`;
        document.getElementById('streak-count').textContent = this.streakCount;
        
        // Update progress bar
        const goalProgress = (this.videosWatched / 50) * 100;
        document.getElementById('goal-bar').style.width = `${Math.min(goalProgress, 100)}%`;
        
        // Update referral stats
        document.getElementById('referral-count').textContent = this.referralCount;
        document.getElementById('referral-earnings').textContent = this.referralEarnings.toFixed(3);
    }
    
    // Animate counter values
    animateCounter(elementId, targetValue) {
        const element = document.getElementById(elementId);
        const startValue = parseFloat(element.textContent) || 0;
        
        anime({
            targets: { value: startValue },
            value: targetValue,
            duration: 1000,
            easing: 'easeOutQuad',
            update: (anim) => {
                element.textContent = anim.animatables[0].target.value.toFixed(3);
            }
        });
    }
    
    // Show notification
    showNotification(message) {
        const notification = document.getElementById('notification');
        const notificationText = document.getElementById('notification-text');
        
        notificationText.textContent = message;
        notification.classList.add('show');
        
        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }
    
    // Check and unlock achievements
    checkAchievements() {
        const achievements = [
            { id: 'first-video', threshold: 1, name: 'First Video' },
            { id: 'ten-videos', threshold: 10, name: '10 Videos' },
            { id: 'one-ton', threshold: 1000, name: '1 TON Earned' }
        ];
        
        achievements.forEach(achievement => {
            if (this.videosWatched >= achievement.threshold) {
                this.unlockAchievement(achievement.id);
            }
        });
    }
    
    // Unlock achievement
    unlockAchievement(achievementId) {
        const achievementElement = document.querySelector(`[data-achievement="${achievementId}"]`);
        if (achievementElement) {
            achievementElement.classList.remove('opacity-50');
            this.showNotification(`Achievement unlocked: ${achievementElement.textContent}`);
        }
    }
    
    // Copy referral link
    copyReferralLink(button) {
        const input = button.previousElementSibling;
        input.select();
        document.execCommand('copy');
        
        const originalText = button.textContent;
        button.textContent = this.currentLang === 'bn' ? 'কপি হয়েছে!' : 'Copied!';
        button.classList.add('bg-green-500');
        
        setTimeout(() => {
            button.textContent = originalText;
            button.classList.remove('bg-green-500');
        }, 2000);
    }
    
    // Format time in MM:SS format
    formatTime(seconds) {
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    }
    
    // Load user data from localStorage
    loadUserData() {
        const savedData = localStorage.getItem('ton-earn-user-data');
        if (savedData) {
            const data = JSON.parse(savedData);
            this.userBalance = data.userBalance || 0;
            this.videosWatched = data.videosWatched || 0;
            this.dailyEarnings = data.dailyEarnings || 0;
            this.totalEarnings = data.totalEarnings || 0;
            this.streakCount = data.streakCount || 0;
            this.referralCount = data.referralCount || 0;
            this.referralEarnings = data.referralEarnings || 0;
        }
        
        this.updateDashboard();
    }
    
    // Save user data to localStorage
    saveUserData() {
        const data = {
            userBalance: this.userBalance,
            videosWatched: this.videosWatched,
            dailyEarnings: this.dailyEarnings,
            totalEarnings: this.totalEarnings,
            streakCount: this.streakCount,
            referralCount: this.referralCount,
            referralEarnings: this.referralEarnings,
            lastSaved: Date.now()
        };
        
        localStorage.setItem('ton-earn-user-data', JSON.stringify(data));
    }
    
    // Start periodic updates
    startPeriodicUpdates() {
        // Update every 30 seconds
        setInterval(() => {
            this.updateDashboard();
            this.saveUserData();
        }, 30000);
        
        // Simulate referral earnings every 2 minutes
        setInterval(() => {
            if (this.referralCount > 0) {
                const earnings = Math.random() * 0.001;
                this.referralEarnings += earnings;
                this.userBalance += earnings;
                this.updateDashboard();
            }
        }, 120000);
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.tonEarnApp = new TONEarnApp();
});

// Handle page visibility changes
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        // Pause video when tab is hidden
        const video = document.getElementById('main-video');
        if (video && !video.paused) {
            video.pause();
        }
    }
});

// Handle beforeunload to save data
window.addEventListener('beforeunload', () => {
    if (window.tonEarnApp) {
        window.tonEarnApp.saveUserData();
    }
});