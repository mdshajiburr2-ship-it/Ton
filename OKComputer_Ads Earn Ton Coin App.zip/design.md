# TON Coin Earning App - Design Style Guide

## Design Philosophy

### Visual Language
The design embraces a modern crypto-aesthetic that balances professionalism with accessibility. Drawing inspiration from contemporary fintech applications and blockchain platforms, the interface uses clean geometric forms, subtle gradients, and sophisticated color palettes to create trust and engagement.

### Color Palette
**Primary Colors:**
- Deep Navy (#1a1d29) - Primary background and text
- Electric Blue (#00d4ff) - TON coin branding and interactive elements
- Soft White (#f8fafc) - Content backgrounds and text on dark surfaces
- Warm Gray (#64748b) - Secondary text and subtle elements

**Accent Colors:**
- Success Green (#10b981) - Positive actions, earnings, confirmations
- Warning Amber (#f59e0b) - Notifications, pending states
- Error Red (#ef4444) - Alerts, errors, critical actions
- Neutral Slate (#475569) - Borders, dividers, inactive states

**Gradient Applications:**
- TON Blue Gradient: Linear gradient from #00d4ff to #0099cc
- Background Gradient: Subtle radial gradient from #1a1d29 to #0f1419
- Card Gradient: Linear gradient from #ffffff to #f1f5f9

### Typography
**Primary Font:** Inter (Sans-serif)
- Headers: Inter Bold (700) - Clean, modern, highly readable
- Body Text: Inter Regular (400) - Optimal for extended reading
- UI Elements: Inter Medium (500) - Balanced weight for buttons and labels

**Secondary Font:** JetBrains Mono (Monospace)
- Crypto Amounts: Used for TON coin balances and transaction values
- Code Elements: Technical information and wallet addresses

### Layout Principles
- **Grid System:** 12-column responsive grid with 24px gutters
- **Spacing Scale:** 4px base unit (4, 8, 12, 16, 24, 32, 48, 64px)
- **Border Radius:** 8px for cards, 4px for buttons, 12px for modals
- **Shadows:** Subtle elevation using rgba(0,0,0,0.1) with 0-4px blur

## Visual Effects & Animations

### Core Animation Library
**Anime.js Integration:**
- Smooth number counting animations for earnings
- Staggered card entrance animations
- Button hover state transitions
- Loading state micro-interactions

### Interactive Elements
**Button Animations:**
- Scale transform: 1.0 to 1.02 on hover
- Color transition: 200ms ease-in-out
- Shadow elevation: Increase on active state

**Card Interactions:**
- Subtle lift effect on hover (2px translateY)
- Border color transition for focus states
- Smooth opacity changes for loading states

### Background Effects
**Shader Implementation:**
- Subtle particle system using p5.js
- Floating geometric shapes in TON blue
- Slow parallax movement on scroll
- Responsive to user interactions

### Text Effects
**Heading Animations:**
- Character-by-character reveal using Splitting.js
- Gradient text animation for TON coin amounts
- Color cycling emphasis for call-to-action text
- Glitch effect for error messages

### Data Visualization
**ECharts.js Integration:**
- Smooth line charts for earning history
- Animated pie charts for portfolio distribution
- Interactive bar charts for daily progress
- Real-time updating with smooth transitions

### Loading States
**Skeleton Screens:**
- Animated placeholders for content loading
- Shimmer effects using CSS gradients
- Progressive image loading with blur-to-sharp transitions
- Micro-interactions for form submissions

### Scroll Animations
**Reveal Animations:**
- Elements fade in when 30% visible in viewport
- Subtle translateY movement (16px) with opacity transition
- Staggered delays for card grids (100ms intervals)
- Parallax background elements (±8% movement)

## Component Styling

### Navigation Bar
- **Style:** Fixed top position with backdrop blur
- **Height:** 64px with centered logo and navigation items
- **Background:** rgba(26, 29, 41, 0.9) with backdrop-filter blur
- **Interactive States:** Smooth underline animations for active tabs

### Video Player Interface
- **Container:** Rounded corners (12px) with subtle border
- **Controls:** Custom-styled with TON blue accent color
- **Progress Bar:** Animated fill with gradient overlay
- **Loading State:** Pulsing skeleton with shimmer effect

### Earning Dashboard Cards
- **Background:** White with subtle shadow and border
- **Hover State:** Lift animation with increased shadow
- **Content Layout:** Grid alignment with consistent spacing
- **Interactive Elements:** Smooth color transitions on hover

### Wallet Interface
- **Balance Display:** Large monospace font with animated counting
- **Transaction List:** Alternating row colors with hover highlights
- **Exchange Interface:** Clean form styling with real-time updates
- **Security Elements:** Subtle lock icons and verification badges

### Language Toggle
- **Design:** Split button with current language highlighted
- **Animation:** Smooth slide transition between languages
- **Icons:** Flag representations with proper aspect ratios
- **Accessibility:** Clear focus states and screen reader support

## Responsive Design

### Breakpoints
- **Mobile:** 320px - 768px (Single column layout)
- **Tablet:** 768px - 1024px (Two column layout)
- **Desktop:** 1024px+ (Three column layout with sidebar)

### Mobile Optimizations
- **Touch Targets:** Minimum 44px for all interactive elements
- **Gesture Support:** Swipe navigation for video carousel
- **Performance:** Reduced animation complexity on slower devices
- **Typography:** Larger base font size (16px) for better readability

### Accessibility Features
- **Color Contrast:** Minimum 4.5:1 ratio for all text
- **Focus Indicators:** Clear visual focus states for keyboard navigation
- **Screen Reader:** Proper ARIA labels and semantic HTML structure
- **Motion Preferences:** Respect prefers-reduced-motion settings

## Brand Integration

### TON Coin Branding
- **Logo Usage:** Proper spacing and sizing guidelines
- **Color Consistency:** Exact TON blue (#0088cc) for brand elements
- **Iconography:** Custom TON coin symbol integration
- **Marketing Copy:** Consistent messaging about earning potential

### Trust Signals
- **Security Badges:** SSL certificates and security provider logos
- **Testimonials:** User success stories with verified earnings
- **Transparency:** Clear terms and earning rate disclosures
- **Support:** Accessible help and FAQ sections